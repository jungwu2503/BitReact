function DateService(publishDate){
    let date = new Date(publishDate);
    let year = date.getFullYear();
    let month = date.getMonth();
    let day = date.getDate();

    return `${year}-${month}-${day}`;
}

export default DateService;