import React from "react";
import PropTypes from 'prop-types';
import './Movie.css';
import {Link} from 'react-router-dom'
import DateService from "../utils/DateService";

function Movie({title,year,summary,poster,bookSeq}){
    poster = "http://localhost:8080/imgs/"+poster;
    return (
        <div className="movie data">
            <Link to="/detail-movie" state={{year,title,summary,poster,bookSeq}}>
                <img src={poster} alt={title} title={title}/>
            </Link>
            <Link to={`/delete/${bookSeq}`}>삭제</Link>
            <h3 className="movie__title">{title}</h3>
            <h5 className="movie__year">{DateService(year)}</h5>
            {/* <ul className="movie__genres">
                {genres.map((genre,index)=>{
                    return <li key={index} className="movie_genre">{genre}</li>
                })}
            </ul> */}
            <p className="movie__summary">{summary.slice(0,180)}</p>
        </div>
    );
}

Movie.propTypes = {
    year : PropTypes.number.isRequired,
    title : PropTypes.string.isRequired,
    summary : PropTypes.string.isRequired,
    poster : PropTypes.string.isRequired,
    bookSeq : PropTypes.number.isRequired,
};

export default Movie;