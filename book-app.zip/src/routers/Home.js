import React,{useState,useEffect} from "react";
import Movie from "../components/Movie";
import './Home.css';

function Home() {
    const [isLoading, setIsLocation] = useState(true);
    const [movies, setMovies] = useState([]);
    
    const getMovieData = () => {
        fetch('http://localhost:8080/book/restful',{method:'GET',})
        .then((response)=>response.json())
        .then((books)=>{
            console.log(books);
            //console.log(data.data.limit);
            setIsLocation(false);
            let movies = books;
            setMovies(movies);
        })
        .catch(e=>console.log(e));
    }

    
    //훅 Hook
    //componentDidMount,componentDitUpdate,componentWillUmmount
    useEffect(()=>{
        console.log('didMount');
        getMovieData();
        console.log('didUpdate');
        return ()=>{
            console.log("willUmmount");
        }
    },[]);
        return (
            <section className="container">
                
                    {isLoading?(
                        <div className="loader">
                            <span className="loader_text">Loading...</span>
                        </div>
                    ):(
                        <div className="movies">
                        {
                            movies.map((book)=>{
                                //console.log(movie);
                                return (
                                    <Movie 
                                        key={book.bookSeq}
                                        id={book.isbn}
                                        year={book.publishDate}
                                        title={book.title}
                                        summary={book.author}
                                        poster={book.bookImage}
                                        bookSeq={book.bookSeq}
                                    />
                                );
                            })
                        }
                        </div>
                    )
                    }
                
            </section>
        );
}

export default Home;