import React,{useEffect} from "react";
import { useParams, useNavigate } from "react-router-dom";

function Delete(){
    let params = useParams();
    let navigate = useNavigate();
    console.log(params.bookSeq);
    //console.log(params.id);
    useEffect(()=>{
        fetch(`http://localhost:8080/book/restful/${params.bookSeq}`,{method:'DELETE',})
        .then((response)=>response.json())
        .then((data)=>{
            console.log(data);
            if(data){
                navigate("/");
            }
        })
        .catch((e)=>console.log(e));
    });

    if(params.bookSeq){
        return null;
    } else {
        return (
            <div>
                <h3>Delete</h3>
            </div>
        );
    }
}

export default Delete;