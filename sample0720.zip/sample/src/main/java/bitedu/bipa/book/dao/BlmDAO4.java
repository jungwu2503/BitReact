package bitedu.bipa.book.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bitedu.bipa.book.utils.ConnectionManager;
import bitedu.bipa.book.vo.BookCopy;

@Repository("blmDAO4")
public class BlmDAO4 {
	
	@Autowired
	private SqlSession sqlSession;
	
	
	public boolean insertBook(BookCopy copy){
		boolean flag = false;
		String sql1 = "insert into book_info values (?,?,?,?)";
		String sql2 = "insert into book_copy(book_isbn) values (?)";
		int affectedCount1 = sqlSession.insert("mapper.book.insertBook", copy);
		Map<String, String> map = new HashMap<String, String>();
		map.put("isbn", copy.getIsbn());
		map.put("image", copy.getBookImage());
		int affectedCount2 = sqlSession.insert("mapper.book.insertCopy",map);
		if(affectedCount1>0&&affectedCount2>0) {
			flag = true;
		}
		return flag;
	}
	
	public ArrayList<BookCopy> selectBookAll(){
		ArrayList<BookCopy> list = null;
		list = (ArrayList)sqlSession.selectList("mapper.book.selectAllBook");
		
		return list;
	}
	public boolean deleteBook(int parseInt) {
		// TODO Auto-generated method stub
		boolean flag = false;
		String sql = "delete from book_copy where book_seq = ?";
		int affectedCount = sqlSession.delete("mapper.book.deleteBook", parseInt);
		if(affectedCount>0) {
			flag = true;
		}
		return flag;
	}
	public BookCopy selectBook(int parseInt) {
		// TODO Auto-generated method stub
		BookCopy copy = null;
		StringBuilder sb = new StringBuilder("select a.*, b.* from book_info a ");
		sb.append("inner join book_copy b on a.book_isbn=b.book_isbn ");
		sb.append("where b.book_seq = ?");
		String sql = sb.toString();
		copy = sqlSession.selectOne("mapper.book.selectBookBySeq",parseInt);
		return copy;
	}
	public boolean updateBook(BookCopy copy) {
		// TODO Auto-generated method stub
		boolean flag = false;
		String sql = "update book_info set book_title = ?, book_author=?, book_published_date = ? where book_isbn = ?";
		int affectedCount = sqlSession.insert("mapper.book.updateBook",copy);
		if(affectedCount>0) {
			flag = true;
		}
		
		return flag;
	}

	public int selectAllCount() {
		// TODO Auto-generated method stub
		int count = 0;
		count = (Integer)sqlSession.selectOne("mapper.book.selectCount");
		return count;
	}

	public ArrayList<BookCopy> selectBookRange(int parseInt, int parseInt2) {
		// TODO Auto-generated method stub
		ArrayList<BookCopy> list = null;
		Map<String, Integer> map = new HashMap<String,Integer>();
		map.put("start", parseInt);
		map.put("end", parseInt2);
		list = (ArrayList)sqlSession.selectList("mapper.book.selectRangeBook",map);
		
		return list;
	}
}







