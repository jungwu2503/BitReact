package bitedu.bipa.book.vo;

public class PagingDataVO {
	private int linePerPage;
	private int pagePerGroup;
	private int lastGroup;
	private boolean isFisrtGroup;
	private boolean isLastGroup;
	
	public PagingDataVO(int totalPage) {
		linePerPage = 5;
		pagePerGroup = 5;
		lastGroup = (int)(Math.ceil(totalPage)/linePerPage);
	}

	public int getLinePerPage() {
		return linePerPage;
	}

	public void setLinePerPage(int linePerPage) {
		this.linePerPage = linePerPage;
	}

	public int getPagePerGroup() {
		return pagePerGroup;
	}

	public void setPagePerGroup(int pagePerGroup) {
		this.pagePerGroup = pagePerGroup;
	}

	public int getLastGroup() {
		return lastGroup;
	}

	public void setLastGroup(int lastGroup) {
		this.lastGroup = lastGroup;
	}

	public boolean isFisrtGroup() {
		return isFisrtGroup;
	}

	public void setFisrtGroup(boolean isFisrtGroup) {
		this.isFisrtGroup = isFisrtGroup;
	}

	public boolean isLastGroup() {
		return isLastGroup;
	}

	public void setLastGroup(boolean isLastGroup) {
		this.isLastGroup = isLastGroup;
	}

	@Override
	public String toString() {
		return "PagingDataVO [linePerPage=" + linePerPage + ", pagePerGroup=" + pagePerGroup + ", lastGroup="
				+ lastGroup + ", isFisrtGroup=" + isFisrtGroup + ", isLastGroup=" + isLastGroup + "]";
	}
	
}
